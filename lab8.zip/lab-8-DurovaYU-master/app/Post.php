<?php
namespace App;
use Illuminate\Session\Store;
class Post{
	private $session;
	public function __constract(Store $session){
		$this->session=$session;
		$this->createDummyData();
	}
	public function getPosts(){
		return $this->session->get('posts');
	}
	public function getPost($id){
		return $this->session->get('posts')[$id];
	}
	public function addPost($title, $content){
		$posts=$this->session->get('posts');
		arrat_push($posts, ['title'=>$title, 'content'=>$content]);
		$this->session->put('posts',$posts);
	}
	public function editPost($id,$title,$content){
		$posts=$this->session->get('posts');
		$posts[$id]=['title'=>$title, 'content'=>$content];
		$this->session->put('posts',$posts);
	}
	private functin createDummyData(){
		$post =[
			'title'=>'Learning Laravel',
			'content'=>'This blog post will get you right on track with Lararvel! '
		],
		[
			'title'=>'Something else',
			'content'=>'Some other content'
		];
		$this->session->put('posts',$posts);
	}
}