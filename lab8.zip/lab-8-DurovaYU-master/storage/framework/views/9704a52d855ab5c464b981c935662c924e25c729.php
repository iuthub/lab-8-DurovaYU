<div>
<a href="<?php echo e(route('admin.create')); ?>" class="btn btn-success">New Post</a>
</div>
<div>
	<h2>Learning Laravel<a href="">Edit</a></h2>
</div>
<?php echo $__env->make('layouts.admin.blade.php', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>