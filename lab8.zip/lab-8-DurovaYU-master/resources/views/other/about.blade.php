@extends('layouts.master')

@section('content')
 <div class="row">
        <div class="col-md-12 text-center">
            <h1 class="post-title">About me</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit rem hic numquam, molestiae vitae reprehenderit dignissimos inventore et asperiores eaque quidem nobis, quasi sed perferendis minus aliquam obcaecati. Id, aliquam.\
            </p>
        </div>
    </div>

@endsection